/* Reading / Listening editor. Uses the LMS's existing React and data validators. */
function lrBuildTest(draft) {
  return {
    ...(draft.id ? {id:draft.id} : {}),
    title:draft.title, lessonGroup:draft.lessonGroup || '', skill:draft.skill,
    sections:draft.sections,
    activities:draft.skill === 'listening' ? draft.activities || [] : [],
    questions:draft.questions.map(q => ({
      text:q.text, type:q.type, section:+q.section,
      ...(q.points ? {points:q.points} : {}),
      ...(q.instruction ? {instruction:q.instruction} : {}),
      keys:q.type === 'multi'
        ? [q.keyText.toUpperCase().replace(/\bAND\b/g,',').split(/[,|;+\s]+/).filter(x=>/^[A-L]$/.test(x)).sort().join(',')]
        : q.keyText.split('|').map(x=>x.trim()).filter(Boolean),
      options:q.optionsText?.split('\n').map(x=>x.trim()).filter(Boolean) || [],
      explanation:q.explanation || ''
    }))
  };
}

function LrLayoutFields({raw,onChange}) {
  const h=v.jsx, hs=v.jsxs;
  let blocks;
  try { blocks=Hh(raw); } catch(error) {
    return hs('details',{className:'lr-editor-details',children:[h('summary',{children:'Sửa bố cục chưa hợp lệ'}),h('p',{role:'alert',children:error.message}),h('textarea',{'aria-label':'Bố cục nâng cao',value:raw,rows:6,onChange:e=>onChange(e.target.value)})]});
  }
  const update=(index,patch)=>onChange(JSON.stringify(blocks.map((b,i)=>i===index?{...b,...patch}:b)));
  const field=(label,value,change,rows=2)=>hs('label',{children:[label,h('textarea',{value:value||'',rows,onChange:e=>change(e.target.value)})]});
  const editable=blocks.map((b,index)=>({b,index})).filter(({b})=>['instruction','note','summary','table'].includes(b.type));
  if(!editable.length)return null;
  return hs('details',{className:'lr-editor-details',children:[
    h('summary',{children:'Bố cục nhóm câu hỏi · bảng / notes'}),
    h('p',{children:'Sửa nội dung ở đây để giữ bảng và ô điền từ đúng vị trí. Các ký hiệu [[1]], [[2]]… là số câu tương ứng.'}),
    editable.map(({b,index})=>hs('section',{className:'lr-layout-fields',children:[
      h('h4',{children:b.type==='table'?'Bảng':b.type==='instruction'?'Hướng dẫn nhóm câu':'Notes / Summary'}),
      b.type==='instruction'?field('Nội dung hướng dẫn',b.text,text=>update(index,{text})):
      hs(v.Fragment,{children:[
        field('Tiêu đề khung',b.title,title=>update(index,{title})),
        b.type==='table'?hs('div',{className:'lr-table-editor',children:[
          h('div',{className:'lr-table-row',style:{gridTemplateColumns:`repeat(${b.headers.length},minmax(110px,1fr))`},children:b.headers.map((cell,c)=>field('Tiêu đề cột '+(c+1),cell,value=>update(index,{headers:b.headers.map((x,i)=>i===c?value:x)})))}),
          b.rows.map((row,r)=>h('div',{className:'lr-table-row',style:{gridTemplateColumns:`repeat(${b.headers.length},minmax(110px,1fr))`},children:row.map((cell,c)=>field(`Hàng ${r+1}, cột ${c+1}`,cell,value=>update(index,{rows:b.rows.map((x,i)=>i===r?x.map((y,j)=>j===c?value:y):x)})))}))
        ]}):field('Nội dung · mỗi dòng một ý',(b.lines||[]).join('\n'),text=>update(index,{lines:text.split('\n')}),5)
      ]})
    ]},index))
  ]});
}

function LrDraftPreview({draft,part}) {
  const h=v.jsx, hs=v.jsxs;
  const [answers,setAnswers]=_.useState({});
  const section=draft.sections[part];
  const questions=draft.questions;
  const answer=(index,value)=>setAnswers(old=>({...old,[index]:value}));
  function renderQuestion(index,withInstruction=true){
    const q=questions[index];
    if(!q)return null;
    return hs(v.Fragment,{children:[
      withInstruction&&q.instruction&&h('div',{className:'lr-instructions',children:q.instruction}),
      hs('div',{className:'lr-question',children:[
        h('div',{className:'lr-question-top',children:h('span',{className:'lr-number',children:Bv(q,index)})}),
        h('div',{className:'lr-question-main',children:h(Qv,{q:{...q,options:q.optionsText?.split('\n').filter(Boolean)||q.options||[]},index,value:answers[index]||'',disabled:false,storageKey:'editor-preview:q:'+index,onChange:value=>answer(index,value)})})
      ]})
    ]},index);
  }
  if(!section)return null;
  return hs('div',{className:'lr-test-room paper-room lr-redesign lr-preview-surface skill-'+draft.skill,children:[
    hs('div',{className:'lr-preview-topline',children:[h('span',{children:draft.skill==='reading'?'READING':'LISTENING'}),h('span',{children:'Phần '+(part+1)+' / '+draft.sections.length})]}),
    hs('div',{className:'lr-split',children:[
      h('article',{className:'lr-source',children:hs('div',{className:'lr-pane-inner',children:[
        hs('div',{className:'lr-source-heading',children:[h('span',{children:draft.skill==='reading'?'READING PASSAGE':'LISTENING PART'}),h('h2',{children:section.title||'Tiêu đề phần'})]}),
        draft.skill==='listening'&&h('div',{className:'lr-preview-audio',children:section.audio?'Audio đã được gắn cho phần này':'Thêm audio trước khi lưu đề Listening.'}),
        h('div',{className:'lr-passage reading',children:hs(v.Fragment,{children:[
          section.image&&h('img',{src:section.image,alt:'Hình minh họa đề'}),
          h(zv,{text:section.text||'Nội dung đề sẽ hiện ở đây khi bạn nhập.',storageKey:'editor-preview:passage:'+part,ranges:draft.skill==='reading'?Nv(section.text||'',section.layout):undefined},part)
        ]})})
      ]})}),
      h('section',{className:'lr-questions',children:hs('div',{className:'lr-pane-inner',children:[
        hs('div',{className:'lr-question-header',children:[h('h2',{children:'Questions'}),h('span',{children:questions.filter(q=>+q.section===part).length+' câu'})]}),
        section.layout?h(Wv,{raw:section.layout,questions,part,answers,disabled:false,onChange:answer,renderQuestion,storageKey:'editor-preview:layout:'+part}):questions.map((q,index)=>+q.section===part&&renderQuestion(index,!index||questions[index-1]?.instruction!==q.instruction)),
        !questions.some(q=>+q.section===part)&&h('p',{className:'lr-preview-empty',children:'Thêm câu hỏi để xem bố cục đề.'})
      ]})})
    ]})
  ]});
}

function LrImportEditor({draft:d,onChange:setDraft,onSave,onQuickImport,lessonOptions,busy,demo}) {
  const h=v.jsx, hs=v.jsxs;
  const [tab,setTab]=_.useState('content');
  const [part,setPart]=_.useState(0);
  const [message,setMessage]=_.useState('');
  const [error,setError]=_.useState('');
  const [preview,setPreview]=_.useState(true);
  const [dragging,setDragging]=_.useState(false);
  const fileInput=_.useRef(null);
  const active=Math.min(part,d.sections.length-1);
  const current=d.sections[active];
  const types=[['text','Điền từ / nối đáp án'],['choice','Trắc nghiệm một đáp án'],['multi','Trắc nghiệm chọn nhiều đáp án'],['match','Matching · danh sách chọn'],['tfng','True / False / Not Given'],['ynng','Yes / No / Not Given']];
  const change=(patch)=>{setDraft({...d,...patch});setError('');};
  const editSection=(patch)=>change({sections:d.sections.map((s,i)=>i===active?{...s,...patch}:s)});
  const editQuestion=(index,patch)=>change({questions:d.questions.map((q,i)=>i===index?{...q,...patch}:q)});
  const field=(label,value,onChange,opts={})=>hs('label',{children:[label,h(opts.multiline?'textarea':'input',{'aria-label':label,value:value||'',maxLength:opts.maxLength||50000,...opts.multiline?{rows:opts.rows||4}:{type:opts.type||'text'},required:!!opts.required,placeholder:opts.placeholder,onChange:e=>onChange(e.target.value)})]});
  async function importFile(file){
    if(!file)return;
    try{
      if(file.size>3000000)throw Error('Tệp JSON tối đa 3 MB.');
      if(!/\.json$/i.test(file.name))throw Error('Chọn tệp .json hoặc dùng Nhập từ Word / văn bản.');
      let data=JSON.parse(await file.text());
      if(data.reading||data.listening)data=Vh(data,d.skill);
      if(!data||!['reading','listening'].includes(data.skill)||!Array.isArray(data.sections)||!data.sections.length||data.sections.length>4||!Array.isArray(data.questions)||data.questions.length>40)throw Error('Tệp cần có Reading/Listening, 1–4 phần và tối đa 40 câu hỏi.');
      const candidate={...d,...data,id:d.id,type:'test',lessonGroup:data.lessonGroup||d.lessonGroup||'',questions:data.questions.map(q=>({...q,keyText:(q.keys||[]).join(' | '),optionsText:(q.options||[]).join('\n')}))};
      if(!(candidate.skill==='listening'&&candidate.sections.some(s=>!s.audio)))Zh(lrBuildTest(candidate));
      setDraft(candidate);setPart(0);setTab('content');setError('');setMessage(`Đã nhập ${data.sections.length} phần · ${data.questions.length} câu. Kiểm tra bản xem trước rồi lưu.`);
    }catch(e){setError(e.message);}
    finally{if(fileInput.current)fileInput.current.value='';}
  }
  async function importKeys(file){
    if(!file)return;
    try{
      if(file.size>1000000)throw Error('Tệp đáp án tối đa 1 MB.');
      const rows=Jh(await file.text());if(/number|câu|no/i.test(rows[0]?.[0]||''))rows.shift();
      const questions=d.questions.map(q=>({...q}));
      for(const row of rows){const i=questions.findIndex((q,i)=>Number(Bv(q,i))===Number(row[0]));if(i<0||!row[1])throw Error('Kiểm tra số câu và đáp án trong tệp.');questions[i].keyText=row[1];questions[i].explanation=row[2]||'';}
      change({questions});setMessage('Đã nhập đáp án. Kiểm tra key trước khi lưu.');
    }catch(e){setError(e.message);}
  }
  function removePart(){
    if(d.sections.length===1)return;
    const count=d.questions.filter(q=>+q.section===active).length;
    if(!confirm(`Bỏ phần ${active+1} và ${count} câu thuộc phần này khỏi bản đang soạn? Bài đã giao được giữ nguyên.`))return;
    change({sections:d.sections.filter((_,i)=>i!==active),questions:d.questions.filter(q=>+q.section!==active).map(q=>({...q,section:+q.section>active?q.section-1:+q.section})),activities:(d.activities||[]).filter(a=>+a.section!==active).map(a=>({...a,section:+a.section>active?a.section-1:+a.section}))});setPart(0);
  }
  const partTabs=hs('nav',{className:'lr-editor-parts','aria-label':'Chọn phần đề',children:[
    d.sections.map((s,i)=>hs('button',{type:'button',className:active===i?'active':'','aria-current':active===i?'step':undefined,onClick:()=>setPart(i),children:[h('span',{children:(d.skill==='reading'?'Passage ':'Part ')+(i+1)}),h('small',{children:d.questions.filter(q=>+q.section===i).length+' câu'})]},i)),
    d.sections.length<4&&h('button',{type:'button',className:'lr-add-part',onClick:()=>{change({sections:[...d.sections,{title:(d.skill==='reading'?'Passage ':'Part ')+(d.sections.length+1),text:'',audio:'',image:''}]});setPart(d.sections.length);},children:'+ Thêm phần'})
  ]});
  const selectedQuestions=d.questions.map((q,index)=>({q,index})).filter(({q})=>+q.section===active);
  return hs('form',{className:'lr-editor '+(!preview?'without-preview ':''),onSubmit:e=>{e.preventDefault();try{const payload=lrBuildTest(d);Zh(payload);setError('');onSave(payload);}catch(err){setError(err.message);}},children:[
    hs('header',{className:'lr-editor-header',children:[
      hs('div',{children:[h('div',{className:'lr-editor-eyebrow',children:'READING & LISTENING · THƯ VIỆN ĐỀ'}),h('h2',{children:d.id?'Chỉnh sửa đề':'Soạn & nhập đề'}),h('p',{children:'Nhập nội dung, kiểm tra cách hiển thị và lưu đề vào kho.'})]}),
      h('span',{className:'lr-editor-count',children:d.sections.length+' phần · '+d.questions.length+' câu'})
    ]}),
    hs('div',{className:'lr-editor-tabs',children:[
      [['content','01','Nội dung đề'],['questions','02','Câu hỏi & key'],['preview','03','Xem toàn đề']].map(([id,num,label])=>hs('button',{type:'button',className:tab===id?'active':'','aria-pressed':tab===id,onClick:()=>setTab(id),children:[h('span',{children:num}),label]},id)),
      tab!=='preview'&&h('button',{type:'button',className:'lr-preview-toggle','aria-pressed':preview,onClick:()=>setPreview(!preview),children:preview?'Ẩn xem trước':'Hiện xem trước'})
    ]}),
    message&&h('div',{className:'lr-editor-message',role:'status',children:message}),
    error&&h('div',{className:'lr-editor-error',role:'alert',children:error}),
    d.importWarnings?.length>0&&h('div',{className:'lr-editor-error',children:d.importWarnings.map((text,i)=>h('p',{children:text},i))}),
    tab==='preview'?hs('div',{className:'lr-editor-fullpreview',children:[partTabs,h(LrDraftPreview,{draft:d,part:active})]}):hs('div',{className:'lr-editor-columns',children:[
      hs('div',{className:'lr-editor-fields',children:[
        tab==='content'&&hs(v.Fragment,{children:[
          hs('div',{className:'lr-editor-drop '+(dragging?'dragging':''),onDragOver:e=>{e.preventDefault();setDragging(true);},onDragLeave:()=>setDragging(false),onDrop:e=>{e.preventDefault();setDragging(false);importFile(e.dataTransfer.files?.[0]);},children:[
            h('div',{className:'lr-upload-icon',children:h(K_,{size:22})}),
            h('strong',{children:'Kéo tệp đề vào đây'}),h('span',{children:'JSON từ Mock Test hoặc bộ đề đã xuất'}),
            hs('div',{className:'lr-editor-file-actions',children:[h('button',{type:'button',className:'primary',onClick:()=>fileInput.current?.click(),children:'Chọn tệp JSON'}),h('button',{type:'button',className:'outline',onClick:()=>{if(confirm('Chuyển sang nhập Word / văn bản? Các thay đổi trong bản đang soạn sẽ được thay thế.'))onQuickImport();},children:'Word / văn bản'})]}),
            h('input',{ref:fileInput,type:'file',accept:'.json,application/json','aria-label':'Nhập đề JSON',className:'lr-visually-hidden',onChange:e=>importFile(e.target.files?.[0])})
          ]}),
          field('Tên đề',d.title,value=>change({title:value}),{required:true,maxLength:180,placeholder:'Ví dụ: Lesson 7 — Technology'}),
          hs('div',{className:'lr-editor-meta',children:[
            hs('label',{children:['Kỹ năng',h('select',{value:d.skill,onChange:e=>change({skill:e.target.value}),children:[h('option',{value:'reading',children:'Reading'}),h('option',{value:'listening',children:'Listening'})]})]}),
            h(M,{value:d.lessonGroup,options:lessonOptions,onChange:value=>change({lessonGroup:value})})
          ]}),
          partTabs,
          field('Tên phần',current.title,value=>editSection({title:value}),{required:true,maxLength:200}),
          field(d.skill==='reading'?'Bài đọc':'Hướng dẫn / ghi chú đề',current.text,value=>editSection({text:value}),{multiline:true,rows:10,placeholder:'Dán nội dung đề. Ngăn các đoạn bằng một dòng trống.'}),
          hs('label',{className:'lr-inline-file',children:['Hoặc đọc nội dung từ TXT',h('input',{type:'file',accept:'.txt',onChange:async e=>{const file=e.target.files?.[0];if(!file)return;if(file.size>200000){setError('Tệp nội dung tối đa 200 KB.');return;}editSection({text:await file.text()});}})]}),
          d.skill==='listening'&&hs('section',{className:'lr-editor-audio',children:[h('h3',{children:'Audio · Part '+(active+1)}),h(Tv,{value:current.audio||'',demo,onChange:value=>editSection({audio:value})})]}),
          current.layout&&h(LrLayoutFields,{raw:current.layout,onChange:value=>editSection({layout:value})}),
          hs('details',{className:'lr-editor-details',children:[h('summary',{children:'Hình minh họa & transcript'}),field('Link hình / bản đồ',current.image,value=>editSection({image:value}),{type:'url',maxLength:2000}),d.skill==='listening'&&field('Transcript · chỉ mở sau khi nộp',current.transcript,value=>editSection({transcript:value}),{multiline:true,rows:5})]}),
          d.sections.length>1&&h('button',{type:'button',className:'text-btn danger-text',onClick:removePart,children:'Bỏ phần này khỏi bản soạn'})
        ]}),
        tab==='questions'&&hs(v.Fragment,{children:[
          partTabs,
          hs('div',{className:'lr-editor-section-heading',children:[h('h3',{children:'Câu hỏi · '+(d.skill==='reading'?'Passage ':'Part ')+(active+1)}),h('span',{children:selectedQuestions.length+' câu'})]}),
          hs('label',{className:'lr-inline-file',children:['Nhập key CSV / TSV',h('input',{type:'file',accept:'.csv,.tsv,.txt','aria-label':'Nhập đáp án CSV',onChange:e=>importKeys(e.target.files?.[0])})]}),
          selectedQuestions.map(({q,index})=>hs('details',{className:'lr-editor-question',open:selectedQuestions.length===1,children:[
            hs('summary',{children:[h('b',{children:Bv(q,index)}),h('span',{children:Vv(q).slice(0,85)||'Câu hỏi mới'}),h('small',{children:types.find(([type])=>type===q.type)?.[1]})]}),
            hs('div',{className:'lr-editor-question-fields',children:[
              hs('div',{className:'lr-editor-meta',children:[hs('label',{children:['Thuộc phần',h('select',{value:q.section,onChange:e=>editQuestion(index,{section:+e.target.value}),children:d.sections.map((s,i)=>h('option',{value:i,children:s.title},i))})]}),hs('label',{children:['Dạng câu',h('select',{value:q.type,onChange:e=>editQuestion(index,{type:e.target.value,...e.target.value!=='multi'?{points:undefined}:{}}),children:types.map(([type,label])=>h('option',{value:type,children:label},type))})]})]}),
              field('Hướng dẫn nhóm câu',q.instruction,value=>editQuestion(index,{instruction:value}),{multiline:true,rows:2,maxLength:4000}),
              field('Câu hỏi / yêu cầu',q.text,value=>editQuestion(index,{text:value}),{multiline:true,rows:3,required:true,maxLength:4000}),
              ['choice','multi','match'].includes(q.type)&&field('Lựa chọn · mỗi dòng A. … / B. …',q.optionsText,value=>editQuestion(index,{optionsText:value}),{multiline:true,rows:5,required:true,maxLength:15000}),
              field('Đáp án · nhiều cách viết ngăn bằng |',q.keyText,value=>editQuestion(index,{keyText:value}),{multiline:true,rows:2,required:true,maxLength:6000}),
              field('Giải thích sau khi nộp',q.explanation,value=>editQuestion(index,{explanation:value}),{multiline:true,rows:3,maxLength:4000}),
              d.questions.length>1&&h('button',{type:'button',className:'text-btn danger-text',onClick:()=>{if(confirm('Xóa câu này khỏi bản đang soạn? Nếu câu có trong bảng/notes, hãy sửa bố cục tương ứng.'))change({questions:d.questions.filter((_,i)=>i!==index)});},children:'Xóa câu hỏi này'})
            ]})
          ]},index)),
          d.questions.length<40&&h('button',{type:'button',className:'outline lr-editor-add-question',onClick:()=>{const next=Math.max(0,...d.questions.map((q,i)=>+Bv(q,i)))+1;change({questions:[...d.questions,{text:next<=40?'[Q'+next+'] ':'',type:'text',section:active,keyText:'',optionsText:'',explanation:''}]});},children:'+ Thêm câu hỏi vào phần này'}),
          d.skill==='listening'&&h(Wy,{activities:d.activities||[],sections:d.sections,onChange:value=>change({activities:value})})
        ]})
      ]}),
      preview&&hs('aside',{className:'lr-editor-preview',children:[hs('div',{className:'lr-preview-heading',children:[h('span',{className:'lr-live-dot'}),h('strong',{children:'Học sinh sẽ thấy'}),h('small',{children:'Thử điền đáp án · không lưu bài làm'})]}),h(LrDraftPreview,{draft:d,part:active})]})
    ]}),
    hs('footer',{className:'lr-editor-footer',children:[
      h('span',{children:'Chỉ lưu vào kho khi bạn bấm Lưu đề & đáp án.'}),
      h('button',{type:'button',className:'outline',onClick:()=>setTab(tab==='preview'?'content':'preview'),children:tab==='preview'?'Quay lại chỉnh sửa':'Xem toàn đề'}),
      h('button',{type:'button',className:'primary',disabled:busy,onClick:()=>{try{const payload=lrBuildTest(d);Zh(payload);setError('');onSave(payload);}catch(err){setError(err.message);}},children:busy?'Đang lưu…':'Lưu đề & đáp án'})
    ]})
  ]});
}
