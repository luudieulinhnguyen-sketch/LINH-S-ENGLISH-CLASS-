from pathlib import Path
import re, base64, hashlib, json, subprocess

root=Path(__file__).resolve().parent
source=root/'existing-bundle-0.js'
bundle=source.read_text()
start=bundle.index('b.type===`test`&&(0,v.jsxs)(`form`,')
end=bundle.index('b.type===`testAssign`',start)
assert bundle[end-3:end]==']}),' or bundle[end-2:end]=='),',bundle[end-15:end]
replacement='b.type===`test`&&(0,v.jsx)(LrImportEditor,{draft:b,onChange:x,onSave:e=>R(`test`,e),onQuickImport:()=>x({type:`quickImport`}),lessonOptions:k(u.lrTests,u.lrAssignments),busy:g,demo:O}),'
updated=bundle[:start]+replacement+bundle[end:]
assert updated.count('className:`lr-test-room paper-room compact-room ')==1
updated=updated.replace('className:`lr-test-room paper-room compact-room ','className:`lr-test-room paper-room compact-room lr-redesign ',1)
assert updated.count('[B,V]=(0,_.useState)(18)')==1
updated=updated.replace('[B,V]=(0,_.useState)(18)','[B,V]=(0,_.useState)(16)',1)
pos=updated.rfind('(0,T.createRoot)')
assert pos>0
updated=updated[:pos]+(root/'reading-listening-editor.js').read_text()+'\n'+updated[pos:]
(root/'classroom-bundle.js').write_text(updated)
subprocess.run(['node','--check',str(root/'classroom-bundle.js')],check=True)
original=(root/'index.html').read_text()
# Use the original materialized HTML only once, then retain its bytes for reproducible rebuilds.
original_path=root/'original-index.html'
if not original_path.exists(): original_path.write_text(original)
else: original=original_path.read_text()
css=(root/'reading-listening-design.css').read_text()
encoded=base64.b64encode(updated.encode()).decode()
html=re.sub(r'data:text/javascript;base64,[^"\s]+',lambda _: 'data:text/javascript;base64,'+encoded,original,count=1)
html=html.replace('</head>','<style id="lr-redesign-20261109">\n'+css+'\n</style></head>',1)
(root/'index.html').write_text(html)
(root/'dist').mkdir(exist_ok=True)
(root/'dist/index.html').write_text(html)
manifest={'base_library_file_id':'libfile_6499a183129c8191841effa4883d5a06','base_library_version':30,'reference':'IELTS-Mock-Test-2-Source-v11.zip','source_sha256':hashlib.sha256(bundle.encode()).hexdigest(),'output_sha256':hashlib.sha256(html.encode()).hexdigest(),'scope':['Reading/Listening import editor','Reading/Listening student presentation','Default reading font 16px'],'unchanged':['Authentication and Firebase configuration','Assignments and submissions','Server grading functions','Writing and sentence translation']}
(root/'CHANGELOG.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False))
print('Built index.html:',len(html.encode()),'bytes. Replaced only the Reading/Listening editor component and presentation hooks.')
